import flet as ft

def main(page: ft.Page): 
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment= ft.CrossAxisAlignment.CENTER
    page.auto_scroll = True

    def change_txt(e):
        if text_ans.value != "":
            if text_ans.value == "Да" or text_ans.value == "да" or text_ans.value == "ДА":
                text.value = "Вы чертовски правы!"
            elif text_ans.value == "Нет" or text_ans.value == "НЕТ" or text_ans.value == "нет":
                text.value = "Вы врете, он еще тот говноед!"
            else:
                text.value = "Правильный ответ, Рома говноед!"
            page.update()

    page.title = "Приложение"
    text = ft.Text("Рома говноед?!", size=65)
    btn = ft.ElevatedButton(text="Ответить", on_click=change_txt ,height=100, width=200)
    text_ans = ft.TextField(label="Введите ответ",width=150, text_size=60)

    page.add(text,text_ans,btn)

ft.app(main)